<?php
		include '../../debug/ChromePhp.php';
		ChromePhp::log('phpDebug.php: Hello World');
        ChromePhp::log($_SERVER);	
        ChromePhp::warn('phpDebug.php : Insert PHP Trace Error Mesasage');	


?>