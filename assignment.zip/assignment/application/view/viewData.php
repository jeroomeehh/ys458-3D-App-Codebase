<?php
  $jsonArray = json_encode($data);
  echo $jsonArray;
?>


